﻿' *****************************************************************
' Team Number: 22
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Nott, GRN (221018276)
' Team Member 3 Details: Olorundare, JE (220028921)
' Team Member 4 Details: Dallo, HA (221115213)
' Practical: Team Project
' Class name: Venue
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

<Serializable()> Public Class Venue
    'Attributes
    Private _ArrVaccines() As Vaccine
    Private _CenterID As Integer
    Private _EmployeeNames() As String
    Private _NumVaccines As Integer
    Private _NumEmployees As Integer


    'Constructor
    Public Sub New(CenterID As Integer)
        _CenterID = CenterID
        _NumVaccines = 0
        _NumEmployees = 0
    End Sub

    'Property Methods
    Public Property ArrVaccines(index As Integer) As Vaccine
        Get
            Return _ArrVaccines(index)
        End Get
        Set(value As Vaccine)
            _ArrVaccines(index) = value
        End Set
    End Property

    Public Property CenterID As Integer
        Get
            Return _CenterID
        End Get
        Set(value As Integer)
            _CenterID = value
        End Set
    End Property

    Public Property EmployeeNames(index As Integer) As String
        Get
            Return _EmployeeNames(index)
        End Get
        Set(value As String)
            _EmployeeNames(index) = value
        End Set
    End Property

    Public Property NumVaccines As Integer
        Get
            Return _NumVaccines
        End Get
        Set(value As Integer)
            _NumVaccines = value
        End Set
    End Property

    Public Property NumEmployees As Integer
        Get
            Return _NumEmployees
        End Get
        Set(value As Integer)
            _NumEmployees = value
        End Set
    End Property

    'Methods
    Public Sub NewVaccineGiven(ID As Integer, Name As String, Price As Double, DateOrdered As Vaccine.DateStruct, CitizenName As String, CitizenID As String, PhoneNum As String, VaccineDministrator As String)
        'This resizes the array and constructs a new VaccineGivenOut
        _NumVaccines += 1
        ReDim Preserve _ArrVaccines(_NumVaccines)
        _ArrVaccines(_NumVaccines) = New VaccineGivenOut(CitizenID, CitizenName, PhoneNum, VaccineDministrator, ID, Name, Price, DateOrdered)

    End Sub

    Public Sub NewVaccineInStock(ID As Integer, Name As String, Price As Double, DateOrdered As Vaccine.DateStruct, FactoryName As String, StorageCondition As String, TemperatureConditions As VaccineInStock.TemperatureConditions)
        'This resizes the array and constructs a new VaccineInStock
        _NumVaccines += 1
        ReDim Preserve _ArrVaccines(_NumVaccines)
        _ArrVaccines(_NumVaccines) = New VaccineInStock(FactoryName, StorageCondition, TemperatureConditions, ID, Name, Price, DateOrdered)
    End Sub

    Public Sub NewEmployee(Name As String)
        'Add a new employee to the list of employees
        _NumEmployees += 1
        ReDim Preserve _EmployeeNames(_NumEmployees)
        _EmployeeNames(_NumEmployees) = Name
    End Sub

    Public Function TotalVaccineCost() As Double
        'This adds the cost of all individual vaccines together
        Dim temp As Double = 0
        For k As Integer = 1 To NumVaccines
            temp += _ArrVaccines(k).Price
        Next
        Return temp
    End Function

    Public Function EmployeeSalaries() As Double
        'Estimating the employee salary 
        Dim s As Double
        s = CInt(NumEmployees * 1000)
        Return s
    End Function

    Public Function Display() As String
        'Displas all the information 
        Dim temp As String

        temp = "===============================================" & Environment.NewLine
        temp &= " Center ID: " & CStr(_CenterID) & Environment.NewLine & Environment.NewLine



        temp &= " Vaccines in the centre: " & Environment.NewLine
        For k As Integer = 1 To NumVaccines
            temp &= _ArrVaccines(k).ToString() & Environment.NewLine
        Next

        temp &= " Number of Vaccines: " & CStr(_NumVaccines) & Environment.NewLine
        temp &= " Total Cost of Vaccines: " & Format(TotalVaccineCost(), "R0.00") & Environment.NewLine
        temp &= " Number of Employees: " & CStr(_NumEmployees) & Environment.NewLine
        temp &= " Total Cost of Employees: " & Format(EmployeeSalaries, "R0.00") & Environment.NewLine & Environment.NewLine

        temp &= "===============================================" & Environment.NewLine
        Return temp


    End Function
End Class
