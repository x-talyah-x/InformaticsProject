﻿' *****************************************************************
' Team Number: 22
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Nott, GRN (221018276)
' Team Member 3 Details: Olorundare, JE (220028921)
' Team Member 4 Details: Dallo, HA (221115213)
' Practical: Team Project
' Class name: VaccineInStock
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

<Serializable()> Public Class VaccineInStock
    Inherits Vaccine

    'Enumeration 
    Enum TemperatureConditions
        Hot = 0
        CoolArea = 1
        WarmConditions = 2
        Refrigerate = 3
        NormalTemp = 4
    End Enum

    'Attributes 
    Private _FactoryName As String
    Private _StorageConditions As String
    Private _TemperatureConditions As TemperatureConditions
    Private _ExpiryDate As Vaccine.DateStruct

    'Constructor
    Public Sub New(FName As String, StorageConditions As String, TemperatureConditions As TemperatureConditions, ID As Integer, n As String, p As Double, d As Vaccine.DateStruct)
        MyBase.New(ID, n, p, d)
        _FactoryName = FName
        _StorageConditions = StorageConditions
        _TemperatureConditions = TemperatureConditions
        'vaccine expires 30 days after bought
        _ExpiryDate = AddDays(d, 30)
    End Sub

    'Property Methods 
    Public Property FactoryName As String
        Get
            Return _FactoryName
        End Get
        Set(value As String)
            _FactoryName = value
        End Set
    End Property

    Public Property StorageConditions As String
        Get
            Return _StorageConditions
        End Get
        Set(value As String)
            _StorageConditions = value
        End Set
    End Property

    Public Property TemperatureCondition As TemperatureConditions
        Get
            Return _TemperatureConditions
        End Get
        Set(value As TemperatureConditions)
            _TemperatureConditions = value
        End Set
    End Property

    Public Property ExpiryDate As Vaccine.DateStruct
        Get
            Return _ExpiryDate
        End Get
        Set(value As Vaccine.DateStruct)
            _ExpiryDate = value
        End Set
    End Property

    'Methods
    Public Function DetermineNewPrice() As Double
        'Determines the new price based on the conditions
        Dim _NewPrice As Double
        Select Case _TemperatureConditions
            Case TemperatureConditions.Hot
                _NewPrice = Price + 100
            Case TemperatureConditions.CoolArea
                _NewPrice = Price + 35.45
            Case TemperatureConditions.WarmConditions
                _NewPrice = Price + 70
            Case TemperatureConditions.Refrigerate
                _NewPrice = Price + 210.67
            Case TemperatureConditions.NormalTemp
                _NewPrice = Price + 15.17
        End Select
        _Price = _NewPrice
        Return _Price
    End Function

    Public Overrides Function ToString() As String
        Dim temp As String
        temp = MyBase.ToString
        temp &= " Factory Name: " & CStr(_FactoryName) & Environment.NewLine
        temp &= " Storage Conditions: " & CStr(_StorageConditions) & Environment.NewLine
        temp &= " Temperature Conditions: " & CStr(_TemperatureConditions) & Environment.NewLine
        temp &= " Expiry Date: " & FormatDate(ExpiryDate) & Environment.NewLine
        temp &= " New Price, including storage costs: " & FormatPrice(DetermineNewPrice()) & Environment.NewLine
        Return temp
    End Function

    Private Function AddDays(OriginalDate As Vaccine.DateStruct, DaysToAdd As Integer) As Vaccine.DateStruct
        'add days to the date
        Dim temp As DateStruct = OriginalDate
        temp.Day += DaysToAdd

        'Loop: if days is over the number allowed for the month, increase month
        Dim HasValidNumDays As Boolean = False
        While Not HasValidNumDays

            'Determine number of days in the month
            Dim DaysForTheMonth As Integer
            Select Case temp.Month
                Case 1, 3, 5, 7, 8, 10, 12
                    DaysForTheMonth = 31
                Case 2
                    DaysForTheMonth = 29
                Case Else
                    DaysForTheMonth = 30
            End Select

            'if the day is above the allowable number of days for the month, go to the next month
            If temp.Day <= DaysForTheMonth Then
                HasValidNumDays = True
            Else
                temp.Month += 1
                temp.Day -= DaysForTheMonth
            End If
        End While

        'if month > 12, increase year
        Dim HasValidNumMonths As Boolean = False
        While Not HasValidNumMonths
            If temp.Month <= 12 Then
                HasValidNumMonths = True
            Else
                temp.Year += 1
                temp.Month -= 12
            End If
        End While
        Return temp
    End Function
End Class
