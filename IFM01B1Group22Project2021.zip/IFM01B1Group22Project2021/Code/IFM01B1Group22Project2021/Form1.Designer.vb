﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmVaccine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtOutput = New System.Windows.Forms.RichTextBox()
        Me.btnNewVenue = New System.Windows.Forms.Button()
        Me.btnNewVaccine = New System.Windows.Forms.Button()
        Me.btnSaveToFile = New System.Windows.Forms.Button()
        Me.txtSaved = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(305, 15)
        Me.txtOutput.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.Size = New System.Drawing.Size(405, 310)
        Me.txtOutput.TabIndex = 0
        Me.txtOutput.Text = ""
        '
        'btnNewVenue
        '
        Me.btnNewVenue.Location = New System.Drawing.Point(20, 15)
        Me.btnNewVenue.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnNewVenue.Name = "btnNewVenue"
        Me.btnNewVenue.Size = New System.Drawing.Size(250, 50)
        Me.btnNewVenue.TabIndex = 1
        Me.btnNewVenue.Text = "New Venue"
        Me.btnNewVenue.UseVisualStyleBackColor = True
        '
        'btnNewVaccine
        '
        Me.btnNewVaccine.Location = New System.Drawing.Point(20, 106)
        Me.btnNewVaccine.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnNewVaccine.Name = "btnNewVaccine"
        Me.btnNewVaccine.Size = New System.Drawing.Size(250, 50)
        Me.btnNewVaccine.TabIndex = 2
        Me.btnNewVaccine.Text = "New Vaccine"
        Me.btnNewVaccine.UseVisualStyleBackColor = True
        '
        'btnSaveToFile
        '
        Me.btnSaveToFile.Location = New System.Drawing.Point(20, 199)
        Me.btnSaveToFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSaveToFile.Name = "btnSaveToFile"
        Me.btnSaveToFile.Size = New System.Drawing.Size(250, 50)
        Me.btnSaveToFile.TabIndex = 3
        Me.btnSaveToFile.Text = "Save to File"
        Me.btnSaveToFile.UseVisualStyleBackColor = True
        '
        'txtSaved
        '
        Me.txtSaved.Location = New System.Drawing.Point(20, 290)
        Me.txtSaved.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSaved.Multiline = True
        Me.txtSaved.Name = "txtSaved"
        Me.txtSaved.Size = New System.Drawing.Size(250, 35)
        Me.txtSaved.TabIndex = 4
        '
        'frmVaccine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(756, 358)
        Me.Controls.Add(Me.txtSaved)
        Me.Controls.Add(Me.btnSaveToFile)
        Me.Controls.Add(Me.btnNewVaccine)
        Me.Controls.Add(Me.btnNewVenue)
        Me.Controls.Add(Me.txtOutput)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmVaccine"
        Me.Text = "Vaccine Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtOutput As RichTextBox
    Friend WithEvents btnNewVenue As Button
    Friend WithEvents btnNewVaccine As Button
    Friend WithEvents btnSaveToFile As Button
    Friend WithEvents txtSaved As TextBox
End Class
