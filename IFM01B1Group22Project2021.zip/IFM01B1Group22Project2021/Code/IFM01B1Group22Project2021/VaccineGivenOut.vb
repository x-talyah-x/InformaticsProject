﻿' *****************************************************************
' Team Number: 22
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Nott, GRN (221018276)
' Team Member 3 Details: Olorundare, JE (220028921)
' Team Member 4 Details: Dallo, HA (221115213)
' Practical: Team Project
' Class name: VaccineGivenOut
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

<Serializable()> Public Class VaccineGivenOut
    Inherits Vaccine

    'Attributes
    Private _CitizenID As String
    Private _CitizenName As String
    Private _PhonNum As String
    Private _VaccineAdministrator As String

    'Constructor
    Public Sub New(CitizenID As String, CitizenName As String, PhonNum As String, VaccineAdminstrator As String, ID As Integer, n As String, p As Double, d As Vaccine.DateStruct)
        MyBase.New(ID, n, p, d)
        _CitizenID = CitizenID
        _CitizenName = CitizenName
        _PhonNum = PhonNum
        _VaccineAdministrator = VaccineAdminstrator
    End Sub

    'Property Methods
    Public Property CitizenID As String
        Get
            Return _CitizenID
        End Get
        Set(value As String)
            _CitizenID = value
        End Set
    End Property

    Public Property CitizenName As String
        Get
            Return _CitizenName
        End Get
        Set(value As String)
            _CitizenName = value
        End Set
    End Property

    Public Property PhonNum As String
        Get
            Return _PhonNum
        End Get
        Set(value As String)
            _PhonNum = value
        End Set
    End Property

    Public Property VaccineAdministrator As String
        Get
            Return _VaccineAdministrator
        End Get
        Set(value As String)
            _VaccineAdministrator = value
        End Set
    End Property

    'Methods
    Private Function isValid() As Boolean
        'Checks if the phone number and ID are valid
        If Len(_PhonNum) < 10 Or Len(_PhonNum) > 10 Then
            MsgBox("Please Enter Correct Phone Number", MsgBoxStyle.OkCancel)
            Return False

        ElseIf Len(_CitizenID) < 13 Or Len(_CitizenID) > 13 Then
            MsgBox("Please Re-enter Your ID.", MsgBoxStyle.OkCancel)
            Return False
        Else
            Return True
        End If
    End Function

    Public Function Require2ndDose() As Boolean
        'Determines the number of doses
        If _VName = "Pfizer" Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Overrides Function ToString() As String
        Dim requiresDose As String = "No"
        If (Require2ndDose() = True) Then
            requiresDose = "Yes"
        End If

        Dim validated As String = "No"
        If (isValid() = True) Then
            validated = "Yes"
        End If

        Dim temp As String
        temp = MyBase.ToString
        temp &= " CitizenID: " & CStr(_CitizenID) & Environment.NewLine
        temp &= " CitizenName: " & CStr(_CitizenName) & Environment.NewLine
        temp &= " Citizen's Phone Number: " & CStr(_PhonNum) & Environment.NewLine
        temp &= " Vaccine Administrator Name: " & CStr(VaccineAdministrator()) & Environment.NewLine
        temp &= " Is Phone Number/ID Valid? " & validated & Environment.NewLine
        temp &= " Is 2nd Dose Required? " & requiresDose & Environment.NewLine
        Return temp
    End Function
End Class
