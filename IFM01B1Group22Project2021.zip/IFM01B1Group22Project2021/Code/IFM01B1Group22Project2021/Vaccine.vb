﻿' *****************************************************************
' Team Number: 22
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Nott, GRN (221018276)
' Team Member 3 Details: Olorundare, JE (220028921)
' Team Member 4 Details: Dallo, HA (221115213)
' Practical: Team Project
' Class name: Vaccine
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

<Serializable()> Public MustInherit Class Vaccine
    'Attributes
    Protected _VID As Integer
    Protected _VName As String
    Protected _Price As Double
    Protected _DateOrdered As DateStruct

    'Date structure
    <Serializable()> Public Structure DateStruct
        Public Day As Integer
        Public Month As Integer
        Public Year As Integer
    End Structure


    'Constructor
    Public Sub New(ID As Integer, name As String, price As Double, dateOrdered As DateStruct)
        _VID = ID
        _VName = name
        _Price = price
        _DateOrdered = dateOrdered
    End Sub

    'Property Methods
    Public Property VID As Integer
        Get
            Return _VID
        End Get
        Set(value As Integer)
            _VID = value
        End Set
    End Property

    Public Property VName As String
        Get
            Return _VName
        End Get
        Set(value As String)
            _VName = value
        End Set
    End Property

    Public Property Price As Double
        Get
            Return _Price
        End Get
        Set(value As Double)
            _Price = Utility(value)
        End Set
    End Property

    Public Property DateOrdered As DateStruct
        Get
            Return _DateOrdered
        End Get
        Set(value As DateStruct)
            _DateOrdered = value
        End Set
    End Property

    'Methods
    Private Function Utility(value As Double) As Double
        'Method that checks validation  
        If value > 0 Then
            Return value
        Else
            Return 0
        End If
    End Function

    Public Function DetermineTypeFromPrice() As String
        'Method to determine the price
        If _Price > 250 Then
            Return " Single Dose Injection "
        ElseIf _Price > 150 Then
            Return " Half-Dose injection"
        Else
            Return "Nasal vaccination"
        End If
    End Function


    Protected Function FormatPrice(PriceToFormat As Double) As String
        'Returns the price formatted 
        Return "R" + Format(PriceToFormat, "0.00")
    End Function

    Protected Function FormatDate(DateToFormat As DateStruct) As String
        'Returns the price formatted 
        Dim DayAsString As String = CStr(DateToFormat.Day)
        Dim MonthAsString As String = CStr(DateToFormat.Month)
        Dim YearAsString As String = CStr(DateToFormat.Year)

        If Len(DayAsString) = 1 Then
            DayAsString = "0" + DayAsString
        End If
        If Len(MonthAsString) = 1 Then
            MonthAsString = "0" + MonthAsString
        End If
        If Len(YearAsString) = 1 Then
            YearAsString = "0" + YearAsString
        End If


        Return DayAsString & "/" & MonthAsString & "/" & YearAsString
    End Function

    Public Overridable Function ToString() As String
        'Returns the displayed string
        Dim temp As String
        temp = " Vaccine ID: " & CStr(_VID) & Environment.NewLine
        temp &= " Vaccine Name: " & CStr(_VName) & Environment.NewLine
        temp &= " Price: " & FormatPrice(_Price) & Environment.NewLine
        temp &= " Date Ordered: " & FormatDate(_DateOrdered) & Environment.NewLine
        Return temp
    End Function

End Class
