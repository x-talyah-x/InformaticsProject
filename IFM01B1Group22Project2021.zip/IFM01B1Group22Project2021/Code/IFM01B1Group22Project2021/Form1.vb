﻿' *****************************************************************
' Team Number: 22
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Nott, GRN (221018276)
' Team Member 3 Details: Olorundare, JE (220028921)
' Team Member 4 Details: Dallo, HA (221115213)
' Practical: Team Project
' Class name: frmVaccine
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

'Imports
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmVaccine
    'Attributes 
    Private Venues() As Venue
    Private NumVenues As Integer
    Private BF As BinaryFormatter
    Private FS As FileStream
    Private FileName As String = "VenueVaccines.txt"

    'Functions
    Private Sub DisplayAll()
        For k As Integer = 1 To NumVenues
            txtOutput.Text = Venues(k).Display() & Environment.NewLine
        Next
    End Sub

    Private Function ConvertStrToDate(ToConvert As String) As Vaccine.DateStruct    'Date in format DD/MM/YYYY
        Dim temp As Vaccine.DateStruct
        temp.Day = CInt(Mid(ToConvert, 1, 2))
        temp.Month = CInt(Mid(ToConvert, 4, 2))
        temp.Year = CInt(Mid(ToConvert, 7))

        Return temp
    End Function

    'Form load
    Private Sub frmGroupProject_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NumVenues = 0
    End Sub

    'Buttons
    Private Sub btnNewVenue_Click(sender As Object, e As EventArgs) Handles btnNewVenue.Click
        'Resize array
        NumVenues += 1
        ReDim Preserve Venues(NumVenues)

        'Get input from user
        Dim CentreId As Integer = CInt(InputBox("Enter the centre ID for centre " & CStr(NumVenues)))
        Dim NumEmployees As Integer = CInt(InputBox("Enter the number of staff at the venue"))

        'Create venue
        Venues(NumVenues) = New Venue(CentreId)

        For k As Integer = 1 To NumEmployees
            Dim EmployeeName As String = InputBox("Enter the name of employee " & CStr(k))
            Venues(NumVenues).NewEmployee(EmployeeName)
        Next

    End Sub

    Private Sub btnNewVaccine_Click(sender As Object, e As EventArgs) Handles btnNewVaccine.Click
        'Determine whether stored or given out
        Dim StoredOrGiven As Integer = CInt(InputBox("Enter whether the vaccine is:" & Environment.NewLine & " 1: In Stock  2: Has been given out "))

        'Get input from user
        Dim VaccineID As Integer = CInt(InputBox("Enter the vaccine ID"))
        Dim VaccineName As String = InputBox("Enter the vaccine name, e.g. Pfizer/Johnson And Johnson")
        Dim Price As Double = CDbl(InputBox("Enter the vaccine Price"))
        Dim DateOrdered As Vaccine.DateStruct = ConvertStrToDate(InputBox("Enter the date the vaccine was ordered, e.g. 15/10/2021"))


        If StoredOrGiven = 1 Then 'inStock
            'Get input from user 
            Dim FactoryName As String = InputBox("Enter the name of the factory the vaccine was produced at")
            Dim StorageConditions As String = InputBox("Enter the storage conditions, e.g.''Store in a cool dry place'',''Refrigerate'' etc.")
            Dim TempConditionsAsInt As Integer = CInt(InputBox("Enter the temperature conditions. Enter only one of the following numbers" & Environment.NewLine & "0:Hot 1:Cool Area 2:Warm Conditions 3:Refrigerate 4:Normal Temperature"))

            Dim TempConditions As VaccineInStock.TemperatureConditions
            Select Case TempConditionsAsInt
                Case 0
                    TempConditions = VaccineInStock.TemperatureConditions.Hot
                Case 1
                    TempConditions = VaccineInStock.TemperatureConditions.CoolArea
                Case 2
                    TempConditions = VaccineInStock.TemperatureConditions.WarmConditions
                Case 3
                    TempConditions = VaccineInStock.TemperatureConditions.Refrigerate
                Case 4
                    TempConditions = VaccineInStock.TemperatureConditions.NormalTemp
                Case Else
                    MessageBox.Show("Please Enter a valid number for temperature condition")
                    Exit Sub
            End Select

            'create VaccineInStock
            Venues(NumVenues).NewVaccineInStock(VaccineID, VaccineName, Price, DateOrdered, FactoryName, StorageConditions, TempConditions)

        ElseIf StoredOrGiven = 2 Then 'GivenOut
            'Get input from user
            Dim CitizenID As String = InputBox("Enter the ID of the citizen who was vaccinated with the vaccine")
            Dim CitizenName As String = InputBox("Enter the name of the citizen who was vaccinated with the vaccine")
            Dim PhoneNum As String = InputBox("Enter the phone num of the citizen who was vaccinated with the vaccine")
            Dim AdministratorName As String = InputBox("Enter name of the person who administered the vaccine")

            'create VaccineGivenOut 
            Venues(NumVenues).NewVaccineGiven(VaccineID, VaccineName, Price, DateOrdered, CitizenName, CitizenID, PhoneNum, AdministratorName)
        Else
            MessageBox.Show("Error! Vaccine must be either stored or given out!")
        End If

        'Call function to display it
        DisplayAll()
    End Sub

    Private Sub btnSaveToFile_Click(sender As Object, e As EventArgs) Handles btnSaveToFile.Click
        'Saves Venue information to the file 
        FS = New FileStream(FileName, FileMode.Create, FileAccess.Write)
        BF = New BinaryFormatter()

        For k As Integer = 1 To NumVenues
            BF.Serialize(FS, Venues(k))
        Next

        FS.Close()
        txtSaved.Text = "All venues saved to file"
    End Sub
End Class
